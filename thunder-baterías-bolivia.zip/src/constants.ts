export interface Product {
  id: string;
  brand: 'THUNDER' | 'DAMAX';
  category: 'LIVIANO' | 'PESADO';
  amp: number;
  caja: string;
  cca: number | string;
  polaridad: 'Normal' | 'Invertida';
  medidas: string;
  precioLista: number;
  precioDist: number;
  stock: number | string;
}

export const PRODUCTS: Product[] = [
  // THUNDER Models
  { id: 'WFEX40HFD', brand: 'THUNDER', category: 'LIVIANO', amp: 40, caja: 'Alta', cca: 290, polaridad: 'Invertida', medidas: '197x128x227', precioLista: 790, precioDist: 700, stock: 20 },
  { id: 'WFEX40HFE', brand: 'THUNDER', category: 'LIVIANO', amp: 40, caja: 'Alta', cca: 290, polaridad: 'Normal', medidas: '197x128x227', precioLista: 790, precioDist: 700, stock: '—' },
  { id: 'WFEX50HCD', brand: 'THUNDER', category: 'LIVIANO', amp: 50, caja: 'Alta', cca: 380, polaridad: 'Invertida', medidas: '238x128x227', precioLista: 890, precioDist: 800, stock: 150 },
  { id: 'WFEX65D', brand: 'THUNDER', category: 'LIVIANO', amp: 65, caja: 'Alta', cca: 500, polaridad: 'Invertida', medidas: '260x165x225', precioLista: 960, precioDist: 870, stock: 100 },
  { id: 'WFEX65E', brand: 'THUNDER', category: 'LIVIANO', amp: 65, caja: 'Alta', cca: 500, polaridad: 'Normal', medidas: '260x165x225', precioLista: 960, precioDist: 870, stock: '—' },
  { id: 'WFEX95E', brand: 'THUNDER', category: 'LIVIANO', amp: 95, caja: 'Alta', cca: 630, polaridad: 'Normal', medidas: '295x165x235', precioLista: 1160, precioDist: 1070, stock: '—' },
  { id: 'WFEX45D', brand: 'THUNDER', category: 'LIVIANO', amp: 45, caja: 'Baja', cca: 300, polaridad: 'Invertida', medidas: '205x17x175', precioLista: 840, precioDist: 750, stock: 50 },
  { id: 'WFEX60D', brand: 'THUNDER', category: 'LIVIANO', amp: 60, caja: 'Baja', cca: 430, polaridad: 'Invertida', medidas: '245x175x175', precioLista: 910, precioDist: 820, stock: 80 },
  { id: 'WFEX70D', brand: 'THUNDER', category: 'LIVIANO', amp: 70, caja: 'Baja', cca: 500, polaridad: 'Invertida', medidas: '275x175x175', precioLista: 1010, precioDist: 920, stock: 80 },
  { id: 'WFEX80D', brand: 'THUNDER', category: 'LIVIANO', amp: 80, caja: 'Baja', cca: 530, polaridad: 'Invertida', medidas: '275x175x190', precioLista: 1110, precioDist: 1020, stock: 120 },
  { id: 'WFEX100MB', brand: 'THUNDER', category: 'LIVIANO', amp: 100, caja: 'Baja', cca: 680, polaridad: 'Normal', medidas: '360x175x190', precioLista: 1460, precioDist: 1370, stock: 100 },
  { id: 'WFEX110E', brand: 'THUNDER', category: 'PESADO', amp: 110, caja: 'Alta', cca: 700, polaridad: 'Normal', medidas: '330x175x240', precioLista: 1510, precioDist: 1420, stock: 50 },
  { id: 'WFEX150MD', brand: 'THUNDER', category: 'PESADO', amp: 150, caja: 'Alta', cca: 800, polaridad: 'Invertida', medidas: '510x215x230', precioLista: 1960, precioDist: 1870, stock: 200 },
  { id: 'WEX240NOE', brand: 'THUNDER', category: 'PESADO', amp: 240, caja: 'Alta', cca: 1100, polaridad: 'Normal', medidas: '510x215x231', precioLista: 3010, precioDist: 2920, stock: 100 },
  
  // DAMAX Models
  { id: 'ECO45D', brand: 'DAMAX', category: 'LIVIANO', amp: 45, caja: 'Baja', cca: '—', polaridad: 'Invertida', medidas: '205x175x175', precioLista: 810, precioDist: 720, stock: 150 },
  { id: 'ECO60D', brand: 'DAMAX', category: 'LIVIANO', amp: 60, caja: 'Baja', cca: '—', polaridad: 'Invertida', medidas: '245x175x175', precioLista: 870, precioDist: 780, stock: 150 },
  { id: 'ECOC60D', brand: 'DAMAX', category: 'LIVIANO', amp: 50, caja: 'Alta', cca: '—', polaridad: 'Invertida', medidas: '238x128x227', precioLista: 860, precioDist: 770, stock: 150 },
  { id: 'ECO70D', brand: 'DAMAX', category: 'LIVIANO', amp: 70, caja: 'Baja', cca: '—', polaridad: 'Invertida', medidas: '275x175x175', precioLista: 940, precioDist: 850, stock: 100 },
];

export const TEAM = [
  {
    name: 'Ronald Caballero',
    role: 'Gerente de Marca THUNDER Bolivia',
    description: 'Estrategia comercial, expansión del canal y posicionamiento nacional.',
    linkedin: 'https://linkedin.com/in/ronald-david-callero-benalcazar-a678591a4',
    image: 'https://picsum.photos/seed/ronald/400/400'
  }
];

export const TESTIMONIALS = [
  {
    name: 'Juan Pérez',
    location: 'Santa Cruz',
    text: 'Las baterías THUNDER han revolucionado mi flota de taxis. El arranque es inmediato incluso en las mañanas más frías.',
    role: 'Dueño de Flota'
  },
  {
    name: 'María García',
    location: 'La Paz',
    text: 'Como distribuidora, la rotación de THUNDER es increíble. El respaldo técnico de Distribución Rooney nos da mucha seguridad.',
    role: 'Distribuidora Autorizada'
  },
  {
    name: 'Carlos Mendoza',
    location: 'Cochabamba',
    text: 'Excelente relación calidad-precio. La línea DAMAX es perfecta para quienes buscan economía sin sacrificar confiabilidad.',
    role: 'Mecánico Automotriz'
  }
];
