import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Zap, MessageCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '@/src/lib/utils';
import Logo from './Logo';

export function Navbar() {
  const [isOpen, setIsOpen] = React.useState(false);
  const [isScrolled, setIsScrolled] = React.useState(false);
  const location = useLocation();

  React.useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Inicio', path: '/' },
    { name: 'Productos', path: '/productos' },
    { name: 'Nosotros', path: '/acerca-de' },
    { name: 'Contacto', path: '/contacto' },
  ];

  const isHome = location.pathname === '/';

  return (
    <nav className={cn(
      "fixed top-0 left-0 w-full z-50 transition-all duration-500",
      isScrolled || !isHome ? "bg-brand-black/90 backdrop-blur-md border-b border-white/10 h-20" : "bg-transparent h-24"
    )}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full">
        <div className="flex justify-between h-full items-center">
          <Link to="/" className="flex items-center">
            <Logo className="h-12 w-auto" textClassName="text-5xl" />
          </Link>

          {/* Desktop Links */}
          <div className="hidden md:flex items-center space-x-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={cn(
                  "text-sm font-medium uppercase tracking-wider transition-colors hover:text-brand-yellow",
                  location.pathname === link.path ? "text-brand-yellow" : "text-white"
                )}
              >
                {link.name}
              </Link>
            ))}
            <a
              href="https://wa.me/59176238388"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-brand-yellow text-brand-black px-6 py-2 rounded-none font-display text-lg hover:bg-white transition-colors"
            >
              QUIERO SER DISTRIBUIDOR
            </a>
          </div>

          {/* Mobile Toggle */}
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-white">
              {isOpen ? <X className="w-8 h-8" /> : <Menu className="w-8 h-8" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="md:hidden bg-brand-black border-b border-white/10"
          >
            <div className="px-4 pt-2 pb-6 space-y-4">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsOpen(false)}
                  className="block text-xl font-display text-white hover:text-brand-yellow"
                >
                  {link.name}
                </Link>
              ))}
              <a
                href="https://wa.me/59176238388"
                className="block w-full text-center bg-brand-yellow text-brand-black py-3 font-display text-xl"
              >
                QUIERO SER DISTRIBUIDOR
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}

export function Footer() {
  return (
    <footer className="bg-brand-black text-white py-16 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center mb-6">
              <Logo className="h-16 w-auto" textClassName="text-4xl" />
            </Link>
            <p className="text-brand-gray/60 max-w-md mb-8">
              Baterías automotrices de alto rendimiento — Industria Brasileña. 
              Garantizamos energía confiable para cada vehículo en Bolivia.
            </p>
            <div className="flex space-x-4">
              {/* Social links would go here */}
            </div>
          </div>
          
          <div>
            <h4 className="text-brand-yellow mb-6">Navegación</h4>
            <ul className="space-y-4 text-sm text-brand-gray/80">
              <li><Link to="/" className="hover:text-brand-yellow">Inicio</Link></li>
              <li><Link to="/productos" className="hover:text-brand-yellow">Productos</Link></li>
              <li><Link to="/acerca-de" className="hover:text-brand-yellow">Nosotros</Link></li>
              <li><Link to="/contacto" className="hover:text-brand-yellow">Contacto</Link></li>
            </ul>
          </div>
          
          <div>
            <h4 className="text-brand-yellow mb-6">Contacto</h4>
            <ul className="space-y-4 text-sm text-brand-gray/80">
              <li>mi.media.bol@gmail.com</li>
              <li>+591 76238388</li>
              <li>Santa Cruz, Bolivia</li>
            </ul>
          </div>
        </div>
        
        <div className="mt-16 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center text-xs text-brand-gray/40">
          <p>© 2026 Distribución Rooney. Todos los derechos reservados.</p>
          <p className="mt-4 md:mt-0">Diseñado por BORING STUDIO</p>
        </div>
      </div>
    </footer>
  );
}

export function WhatsAppButton() {
  return (
    <a
      href="https://wa.me/59176238388"
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-8 right-8 z-50 bg-[#25D366] text-white p-4 rounded-full shadow-2xl hover:scale-110 transition-transform flex items-center justify-center group"
    >
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" className="w-8 h-8 fill-current">
        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51a12.8 12.8 0 0 0-.57-.01c-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 0 1-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 0 1-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 0 1 2.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0 0 12.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 0 0 5.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 0 0-3.48-8.413Z"/>
      </svg>
      <span className="max-w-0 overflow-hidden group-hover:max-w-xs group-hover:ml-2 transition-all duration-300 whitespace-nowrap font-medium">
        Contactar por WhatsApp
      </span>
    </a>
  );
}
