import React, { useEffect, useMemo } from 'react';
import { motion } from 'motion/react';

export default function Preloader({ onComplete }: { onComplete: () => void }) {
  useEffect(() => {
    // El preloader dura exactamente 3 segundos
    const timer = setTimeout(() => {
      onComplete();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  // Generador programático ajustado para replicar EXACTAMENTE la imagen
  // Ahora genera múltiples rayos que caen uno por uno
  const strikes = useMemo(() => {
    const generatePath = (sx: number, sy: number, ex: number, ey: number, segments: number, spread: number) => {
      let d = `M ${sx} ${sy}`;
      for (let i = 1; i <= segments; i++) {
        const t = i / segments;
        const bx = sx + (ex - sx) * t;
        const by = sy + (ey - sy) * t;
        // Suavizar los extremos para que nazcan y mueran en un punto
        const factor = t < 0.05 ? t * 20 : (t > 0.95 ? (1 - t) * 20 : 1);
        // Reducimos la aleatoriedad extrema para trazos más largos y definidos (como en la foto)
        const nx = bx + (Math.random() - 0.5) * spread * factor;
        const ny = by + (Math.random() - 0.5) * spread * factor;
        d += ` L ${nx} ${ny}`;
      }
      return d;
    };

    const createStrike = (sx: number, sy: number, ex: number, ey: number, delay: number) => {
      // Menos segmentos para trazos más largos, spread moderado para que no sea tan recto ni tan caótico
      const trunk = generatePath(sx, sy, ex, ey, 35, 30); 
      const branches: { path: string, width: number, opacity: number }[] = [];
      
      // Generar ramificaciones a lo largo del tronco
      for (let i = 0; i < 15; i++) { // Reducimos un poco la cantidad de ramas para igualar la foto
         const t = 0.1 + Math.random() * 0.8; // Distribuir a lo largo del rayo
         
         // Punto de origen de la rama en el tronco
         const bx = sx + (ex - sx) * t + (Math.random() - 0.5) * 20;
         const by = sy + (ey - sy) * t + (Math.random() - 0.5) * 20;
         
         const isMajor = Math.random() > 0.8; // 20% de ramas son grandes
         const branchLength = isMajor ? 150 + Math.random() * 200 : 40 + Math.random() * 80;
         
         // Ángulo perpendicular/diagonal al tronco principal
         const angleOffset = (Math.random() > 0.5 ? 1 : -1) * (0.2 + Math.random() * 0.4);
         const angle = Math.atan2(ey - sy, ex - sx) + angleOffset;
         
         const bex = bx + Math.cos(angle) * branchLength;
         const bey = by + Math.sin(angle) * branchLength;
         
         branches.push({
           // Zigzag moderado para las ramas
           path: generatePath(bx, by, bex, bey, isMajor ? 12 : 5, isMajor ? 15 : 8),
           width: isMajor ? 2 : 1,
           opacity: isMajor ? 0.8 : 0.4
         });

         // Sub-ramificaciones para las ramas mayores
         if (isMajor) {
           const numSub = 1 + Math.floor(Math.random() * 2); // Hasta 2 sub-ramas
           for (let j = 0; j < numSub; j++) {
              const st = 0.2 + Math.random() * 0.6;
              const sbx = bx + (bex - bx) * st;
              const sby = by + (bey - by) * st;
              const sLength = branchLength * (0.3 + Math.random() * 0.5);
              const sAngle = angle + (Math.random() > 0.5 ? 1 : -1) * (0.2 + Math.random() * 0.4);
              const sbex = sbx + Math.cos(sAngle) * sLength;
              const sbey = sby + Math.sin(sAngle) * sLength;
              
              branches.push({
                // Zigzag moderado para las sub-ramas
                path: generatePath(sbx, sby, sbex, sbey, 6, 10),
                width: 1,
                opacity: 0.3
              });
           }
         }
      }
      return { trunk, branches, delay };
    };

    return [
      createStrike(850, -50, 150, 1050, 0.0),   // Diagonal derecha a izquierda
      createStrike(250, -50, 650, 1050, 0.6),   // Diagonal izquierda a derecha
      createStrike(500, -50, 450, 1050, 1.2),   // Central casi vertical
      createStrike(950, 100, 300, 1050, 1.8),   // Lateral derecho cruzando
      createStrike(100, -50, 800, 1050, 2.4),   // Lateral izquierdo cruzando
    ];
  }, []);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
      className="fixed inset-0 z-[100] flex items-center justify-center overflow-hidden"
      style={{
        // Fondo azul oscuro texturizado imitando el cielo de la imagen
        background: 'radial-gradient(circle at 50% 50%, #0a1930 0%, #040b1a 60%, #000000 100%)'
      }}
    >
      <svg viewBox="0 0 1000 1000" className="w-full h-full object-cover opacity-100" preserveAspectRatio="xMidYMid slice">
        <defs>
          {/* Filtro de resplandor azul eléctrico EXTREMO para igualar la imagen */}
          <filter id="blue-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur in="SourceGraphic" stdDeviation="2" result="blur1" />
            <feGaussianBlur in="SourceGraphic" stdDeviation="8" result="blur2" />
            <feGaussianBlur in="SourceGraphic" stdDeviation="20" result="blur3" />
            <feGaussianBlur in="SourceGraphic" stdDeviation="40" result="blur4" />
            <feMerge result="blur-merged">
              <feMergeNode in="blur4" />
              <feMergeNode in="blur3" />
              <feMergeNode in="blur2" />
              <feMergeNode in="blur1" />
            </feMerge>
            {/* Matriz de color para un azul cyan muy brillante */}
            <feColorMatrix type="matrix" values="
              0 0 0 0 0.0
              0 0 0 0 0.5
              0 0 0 0 1.0
              0 0 0 1 0" in="blur-merged" result="colored-blur" />
            <feMerge>
              <feMergeNode in="colored-blur" />
              <feMergeNode in="SourceGraphic" />
            </feMerge>
          </filter>
        </defs>
        
        <g filter="url(#blue-glow)">
          {strikes.map((strike, i) => (
            <React.Fragment key={i}>
              {/* Núcleo exterior (Glow extra azul) */}
              <motion.path
                d={strike.trunk}
                fill="none"
                stroke="#4dabf7"
                strokeWidth={12}
                strokeLinecap="round"
                strokeLinejoin="round"
                initial={{ pathLength: 0, opacity: 0 }}
                animate={{ 
                  pathLength: [0, 1, 1, 1, 1],
                  opacity: [0, 0.8, 0.3, 1, 0] 
                }}
                transition={{ duration: 0.8, delay: strike.delay, ease: "easeOut", times: [0, 0.15, 0.3, 0.45, 1], repeat: Infinity, repeatDelay: 2.5 }}
              />
              
              {/* Tronco principal (Núcleo blanco caliente) */}
              <motion.path
                d={strike.trunk}
                fill="none"
                stroke="#ffffff"
                strokeWidth={4}
                strokeLinecap="round"
                strokeLinejoin="round"
                initial={{ pathLength: 0, opacity: 0 }}
                animate={{ 
                  pathLength: [0, 1, 1, 1, 1],
                  opacity: [0, 1, 0.4, 1, 0] 
                }}
                transition={{ duration: 0.8, delay: strike.delay, ease: "easeOut", times: [0, 0.15, 0.3, 0.45, 1], repeat: Infinity, repeatDelay: 2.5 }}
              />

              {/* Ramificaciones */}
              {strike.branches.map((branch, j) => (
                <motion.path
                  key={`branch-${i}-${j}`}
                  d={branch.path}
                  fill="none"
                  stroke="#ffffff"
                  strokeWidth={branch.width}
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  initial={{ pathLength: 0, opacity: 0 }}
                  animate={{ 
                    pathLength: [0, 1, 1, 1, 1],
                    opacity: [0, branch.opacity, branch.opacity * 0.3, branch.opacity, 0]
                  }}
                  transition={{
                    duration: 0.8,
                    delay: strike.delay + 0.05, // Las ramas aparecen un instante después del tronco
                    ease: "easeOut",
                    times: [0, 0.15, 0.3, 0.45, 1],
                    repeat: Infinity,
                    repeatDelay: 2.5
                  }}
                />
              ))}
            </React.Fragment>
          ))}
        </g>
      </svg>
    </motion.div>
  );
}
