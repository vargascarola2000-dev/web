import React from 'react';
import { cn } from '@/src/lib/utils';

interface LogoProps {
  className?: string;
  textClassName?: string;
}

export default function Logo({ className, textClassName }: LogoProps) {
  return (
    <div className={cn("relative flex items-center justify-center", className)}>
      <span 
        className={cn("relative z-10 uppercase", textClassName)}
        style={{ 
          fontFamily: "'Changa', 'Impact', sans-serif",
          fontWeight: 800, 
          color: '#FFF200',
          letterSpacing: '-0.02em',
          // Usamos text-shadow como borde para que no "coma" el color amarillo hacia adentro,
          // manteniendo el grosor máximo de la letra.
          textShadow: `
            -1.5px -1.5px 0 #071E54,
             1.5px -1.5px 0 #071E54,
            -1.5px  1.5px 0 #071E54,
             1.5px  1.5px 0 #071E54,
            -1.5px  0     0 #071E54,
             1.5px  0     0 #071E54,
             0     -1.5px 0 #071E54,
             0      1.5px 0 #071E54
          `,
          lineHeight: 0.9,
          display: 'inline-block',
          padding: '0 15px',
          transform: 'scaleX(1.1)' // Estira horizontalmente para dar ese extra de grosor
        }}
      >
        THUNDER
      </span>
    </div>
  );
}
