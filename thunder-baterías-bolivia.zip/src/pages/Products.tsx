import React from 'react';
import { motion } from 'motion/react';
import { Search, Filter, Zap, Info } from 'lucide-react';
import { PRODUCTS } from '@/src/constants';
import { cn } from '@/src/lib/utils';

export default function Products() {
  const [filter, setFilter] = React.useState({
    brand: 'ALL',
    category: 'ALL',
    polaridad: 'ALL',
  });
  const [search, setSearch] = React.useState('');

  const filteredProducts = PRODUCTS.filter((p) => {
    const matchesBrand = filter.brand === 'ALL' || p.brand === filter.brand;
    const matchesCategory = filter.category === 'ALL' || p.category === filter.category;
    const matchesPolaridad = filter.polaridad === 'ALL' || p.polaridad === filter.polaridad;
    const matchesSearch = p.id.toLowerCase().includes(search.toLowerCase());
    return matchesBrand && matchesCategory && matchesPolaridad && matchesSearch;
  });

  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="bg-brand-black py-20 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-6xl md:text-8xl mb-4">CATÁLOGO OFICIAL <span className="text-brand-yellow">2026</span></h1>
          <p className="text-xl text-brand-gray/60">Encuentra la batería exacta para tu vehículo — Livianos y Pesados.</p>
        </div>
      </section>

      {/* Filters */}
      <section className="sticky top-20 z-40 bg-white border-b border-brand-gray py-6 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row gap-6 items-center justify-between">
            <div className="relative w-full lg:w-96">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-gray/50 w-5 h-5" />
              <input
                type="text"
                placeholder="Buscar por código (ej: WFEX65D)..."
                className="w-full pl-12 pr-4 py-3 border border-brand-gray focus:border-brand-blue outline-none transition-colors"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>

            <div className="flex flex-wrap gap-4 items-center w-full lg:w-auto">
              <div className="flex items-center space-x-2">
                <Filter className="w-4 h-4 text-brand-blue" />
                <span className="text-xs font-bold uppercase tracking-widest text-brand-gray/50">Filtros:</span>
              </div>
              
              <select
                className="bg-brand-gray/30 border-none px-4 py-2 text-sm font-bold outline-none focus:ring-2 focus:ring-brand-blue"
                value={filter.brand}
                onChange={(e) => setFilter({ ...filter, brand: e.target.value })}
              >
                <option value="ALL">TODAS LAS MARCAS</option>
                <option value="THUNDER">THUNDER</option>
                <option value="DAMAX">DAMAX</option>
              </select>

              <select
                className="bg-brand-gray/30 border-none px-4 py-2 text-sm font-bold outline-none focus:ring-2 focus:ring-brand-blue"
                value={filter.category}
                onChange={(e) => setFilter({ ...filter, category: e.target.value })}
              >
                <option value="ALL">TODAS LAS CATEGORÍAS</option>
                <option value="LIVIANO">LIVIANO</option>
                <option value="PESADO">PESADO</option>
              </select>

              <select
                className="bg-brand-gray/30 border-none px-4 py-2 text-sm font-bold outline-none focus:ring-2 focus:ring-brand-blue"
                value={filter.polaridad}
                onChange={(e) => setFilter({ ...filter, polaridad: e.target.value })}
              >
                <option value="ALL">POLARIDAD</option>
                <option value="Normal">NORMAL</option>
                <option value="Invertida">INVERTIDA</option>
              </select>
            </div>
          </div>
        </div>
      </section>

      {/* Product Grid */}
      <section className="py-16 bg-brand-gray/10 min-h-screen">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8 flex items-center justify-between">
            <div className="text-sm font-bold text-brand-gray/50 uppercase tracking-widest">
              Mostrando {filteredProducts.length} modelos
            </div>
          </div>

          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
              {filteredProducts.map((product) => (
                <motion.div
                  layout
                  key={product.id}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="bg-white border border-brand-gray group hover:border-brand-blue transition-all"
                >
                  <div className="p-6">
                    <div className="flex justify-between items-start mb-6">
                      <div className={cn(
                        "px-3 py-1 text-[10px] font-bold tracking-widest uppercase",
                        product.brand === 'THUNDER' ? "bg-brand-blue text-white" : "bg-brand-yellow text-brand-black"
                      )}>
                        {product.brand} {product.brand === 'DAMAX' && '— ECONÓMICA'}
                      </div>
                      <div className="text-[10px] font-bold text-brand-gray/40 uppercase tracking-widest">
                        {product.category}
                      </div>
                    </div>

                    <div className="aspect-square bg-brand-gray/20 mb-6 flex items-center justify-center p-8">
                      <img
                        src={`https://picsum.photos/seed/${product.id}/400/400`}
                        alt={product.id}
                        className="max-w-full h-auto group-hover:scale-110 transition-transform duration-500"
                        referrerPolicy="no-referrer"
                      />
                    </div>

                    <h3 className="text-3xl mb-4">{product.id}</h3>

                    <div className="grid grid-cols-2 gap-y-4 gap-x-6 mb-8 text-xs border-t border-brand-gray pt-6">
                      <div>
                        <span className="block text-brand-gray/50 uppercase mb-1">Capacidad</span>
                        <span className="font-bold text-lg">{product.amp} Ah</span>
                      </div>
                      <div>
                        <span className="block text-brand-gray/50 uppercase mb-1">CCA</span>
                        <span className="font-bold text-lg">{product.cca}</span>
                      </div>
                      <div>
                        <span className="block text-brand-gray/50 uppercase mb-1">Polaridad</span>
                        <span className="font-bold">{product.polaridad}</span>
                      </div>
                      <div>
                        <span className="block text-brand-gray/50 uppercase mb-1">Medidas</span>
                        <span className="font-bold">{product.medidas}</span>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <a
                        href={`https://wa.me/59176238388?text=Hola,%20quisiera%20consultar%20por%20el%20modelo%20${product.id}%20de%20la%20marca%20${product.brand}.`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="block w-full text-center py-4 bg-brand-blue text-white font-display text-xl hover:bg-brand-black transition-colors"
                      >
                        CONSULTAR PRECIO
                      </a>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-32 bg-white border border-dashed border-brand-gray">
              <Info className="w-16 h-16 text-brand-gray/30 mx-auto mb-4" />
              <h3 className="text-3xl mb-2">No se encontraron modelos</h3>
              <p className="text-brand-gray/50">Intenta ajustar los filtros o la búsqueda.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
