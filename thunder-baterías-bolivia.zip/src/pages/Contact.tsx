import React from 'react';
import { motion } from 'motion/react';
import { ChevronDown, ChevronUp, Mail, Phone, MapPin, Send } from 'lucide-react';
import { cn } from '@/src/lib/utils';

export default function Contact() {
  const [openFaq, setOpenFaq] = React.useState<number | null>(0);

  const faqs = [
    {
      q: '¿Cómo puedo convertirme en distribuidor autorizado THUNDER?',
      a: 'Para ser distribuidor, debes contar con un negocio establecido en el sector automotriz. Contáctanos vía WhatsApp o llena el formulario de esta página para que un asesor comercial evalúe tu zona y te brinde las condiciones mayoristas.'
    },
    {
      q: '¿Cuál es el pedido mínimo para iniciar como distribuidor?',
      a: 'El pedido mínimo varía según la zona y el tipo de negocio. Generalmente buscamos aliados que puedan mantener un stock representativo para satisfacer la demanda local.'
    },
    {
      q: '¿Las baterías THUNDER tienen garantía? ¿Por cuánto tiempo?',
      a: 'Sí, todas nuestras baterías cuentan con garantía de fábrica contra defectos de fabricación. El tiempo varía según el modelo (Liviano/Pesado), generalmente entre 12 a 18 meses.'
    },
    {
      q: '¿Qué modelo es compatible con mi vehículo?',
      a: 'Puedes consultar nuestro catálogo en línea o enviarnos una foto de tu batería actual por WhatsApp. Nuestro equipo técnico te indicará el modelo exacto (Ah, CCA y Polaridad) que tu vehículo requiere.'
    },
    {
      q: '¿Qué diferencia hay entre la línea THUNDER y DAMAX?',
      a: 'THUNDER es nuestra línea Premium de alto rendimiento con máxima durabilidad y CCA superior. DAMAX es nuestra línea económica, diseñada para ofrecer confiabilidad a un precio más accesible sin sacrificar la calidad de construcción.'
    },
    {
      q: '¿Realizan envíos a todo Bolivia?',
      a: 'Sí, a través de nuestra red logística llegamos a los 9 departamentos del país. Coordinamos el envío desde nuestros centros de distribución en puntos estratégicos.'
    }
  ];

  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="bg-brand-black py-24 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-6xl md:text-8xl mb-4">¿LISTO PARA UNIRTE A LA <span className="text-brand-yellow">RED THUNDER</span>?</h1>
          <p className="text-xl text-brand-gray/60">Contáctanos y te respondemos en menos de 24 horas.</p>
        </div>
      </section>

      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
            {/* Contact Form */}
            <div>
              <h2 className="text-5xl mb-8">Envíanos un <span className="text-brand-blue">Mensaje</span></h2>
              <form className="space-y-6" onSubmit={(e) => e.preventDefault()}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-brand-gray/50">Nombre Completo</label>
                    <input type="text" className="w-full p-4 bg-brand-gray/20 border-none outline-none focus:ring-2 focus:ring-brand-blue" placeholder="Ej: Juan Pérez" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-brand-gray/50">Ciudad</label>
                    <input type="text" className="w-full p-4 bg-brand-gray/20 border-none outline-none focus:ring-2 focus:ring-brand-blue" placeholder="Ej: Santa Cruz" />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-brand-gray/50">Teléfono / WhatsApp</label>
                    <input type="tel" className="w-full p-4 bg-brand-gray/20 border-none outline-none focus:ring-2 focus:ring-brand-blue" placeholder="+591 ..." />
                  </div>
                  <div className="space-y-2">
                    <label className="text-xs font-bold uppercase tracking-widest text-brand-gray/50">Email</label>
                    <input type="email" className="w-full p-4 bg-brand-gray/20 border-none outline-none focus:ring-2 focus:ring-brand-blue" placeholder="correo@ejemplo.com" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-brand-gray/50">Tipo de Consulta</label>
                  <select className="w-full p-4 bg-brand-gray/20 border-none outline-none focus:ring-2 focus:ring-brand-blue appearance-none">
                    <option>Quiero ser distribuidor</option>
                    <option>Consulta técnica de producto</option>
                    <option>Garantías</option>
                    <option>Otro</option>
                  </select>
                </div>

                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-brand-gray/50">Mensaje</label>
                  <textarea rows={5} className="w-full p-4 bg-brand-gray/20 border-none outline-none focus:ring-2 focus:ring-brand-blue resize-none" placeholder="Cuéntanos cómo podemos ayudarte..."></textarea>
                </div>

                <button className="w-full py-5 bg-brand-blue text-white font-display text-2xl hover:bg-brand-black transition-colors flex items-center justify-center">
                  ENVIAR SOLICITUD <Send className="ml-3 w-6 h-6" />
                </button>
              </form>
            </div>

            {/* FAQs & Info */}
            <div>
              <h2 className="text-5xl mb-8">Preguntas <span className="text-brand-blue">Frecuentes</span></h2>
              <div className="space-y-4 mb-16">
                {faqs.map((faq, i) => (
                  <div key={i} className="border border-brand-gray overflow-hidden">
                    <button
                      onClick={() => setOpenFaq(openFaq === i ? null : i)}
                      className="w-full flex justify-between items-center p-6 text-left hover:bg-brand-gray/10 transition-colors"
                    >
                      <span className="font-bold text-lg">{faq.q}</span>
                      {openFaq === i ? <ChevronUp className="w-5 h-5 text-brand-blue" /> : <ChevronDown className="w-5 h-5" />}
                    </button>
                    {openFaq === i && (
                      <div className="p-6 pt-0 text-brand-gray/70 leading-relaxed border-t border-brand-gray">
                        {faq.a}
                      </div>
                    )}
                  </div>
                ))}
              </div>

              <div className="bg-brand-black p-10 text-white">
                <h3 className="text-3xl mb-8 text-brand-yellow">Información Directa</h3>
                <div className="space-y-6">
                  <div className="flex items-start space-x-4">
                    <Phone className="w-6 h-6 text-brand-yellow shrink-0" />
                    <div>
                      <div className="text-xs font-bold uppercase tracking-widest text-white/40 mb-1">Llámanos o Escríbenos</div>
                      <div className="text-xl">+591 76238388</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-4">
                    <Mail className="w-6 h-6 text-brand-yellow shrink-0" />
                    <div>
                      <div className="text-xs font-bold uppercase tracking-widest text-white/40 mb-1">Correo Electrónico</div>
                      <div className="text-xl">mi.media.bol@gmail.com</div>
                    </div>
                  </div>
                  <div className="flex items-start space-x-4">
                    <MapPin className="w-6 h-6 text-brand-yellow shrink-0" />
                    <div>
                      <div className="text-xs font-bold uppercase tracking-widest text-white/40 mb-1">Oficina Central</div>
                      <div className="text-xl">Santa Cruz - Bolivia, Manzana 40, piso 9</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
