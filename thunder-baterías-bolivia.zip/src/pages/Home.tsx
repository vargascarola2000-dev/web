import React, { useEffect, useState } from 'react';
import { motion, useAnimation, useInView } from 'motion/react';
import { Zap, Shield, Truck, Settings, ChevronRight, Star, Globe } from 'lucide-react';
import { Link } from 'react-router-dom';
import { PRODUCTS, TESTIMONIALS, TEAM } from '@/src/constants';

function Counter({ value, duration = 2 }: { value: number; duration?: number }) {
  const [count, setCount] = useState(0);
  const ref = React.useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const end = value;
      if (start === end) return;

      const incrementTime = (duration * 1000) / end;
      
      const timer = setInterval(() => {
        start += 1;
        setCount(start);
        if (start === end) clearInterval(timer);
      }, incrementTime);

      return () => clearInterval(timer);
    }
  }, [value, duration, isInView]);

  return <span ref={ref} className="text-7xl md:text-[7rem] font-display text-brand-yellow tracking-tight leading-none">{count}</span>;
}

export default function Home() {
  const [isCenterHovered, setIsCenterHovered] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const containerRef = React.useRef<HTMLDivElement>(null);

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    setMousePos({
      x: e.clientX - rect.left,
      y: e.clientY - rect.top,
    });
  };

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center bg-black overflow-hidden">
        {/* Background Effects - Realistic Lightning (Image 2) */}
        <div className="absolute inset-0 pointer-events-none bg-black">
          {/* Lightning Flash Animation 1 */}
          <motion.div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat mix-blend-screen"
            style={{
              // Sube tu imagen de rayos a la carpeta "public" con el nombre "rayos-azules.png"
              backgroundImage: `url('/rayos-azules.png')`,
            }}
            animate={{ 
              opacity: [0, 0, 1, 0.2, 0.9, 0, 0],
              filter: ['brightness(1)', 'brightness(1)', 'brightness(1.5)', 'brightness(1)', 'brightness(1.5)', 'brightness(1)', 'brightness(1)']
            }}
            transition={{ 
              duration: 6, 
              repeat: Infinity,
              times: [0, 0.85, 0.87, 0.89, 0.92, 0.95, 1],
              ease: "linear"
            }}
          />
          
          {/* Lightning Flash Animation 2 (Offset for more realism) */}
          <motion.div
            className="absolute inset-0 bg-cover bg-center bg-no-repeat mix-blend-screen"
            style={{
              backgroundImage: `url('/rayos-azules.png')`,
              transform: 'scaleX(-1)' // Flipped horizontally
            }}
            animate={{ 
              opacity: [0, 0, 0.8, 0.1, 1, 0, 0],
            }}
            transition={{ 
              duration: 8, 
              repeat: Infinity,
              times: [0, 0.45, 0.47, 0.49, 0.52, 0.55, 1],
              ease: "linear"
            }}
          />

          {/* Dark overlay to blend edges and keep focus on the battery */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_transparent_0%,_black_80%)]" />
        </div>

        <div className="relative z-10 flex flex-col items-center justify-center w-full h-full px-4 pt-20">
          {/* Espacio reservado para la batería futura */}
          <motion.div
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
            className="relative w-full max-w-md md:max-w-xl flex justify-center items-center min-h-[400px]"
          >
            {/* La imagen de la batería ha sido removida según lo solicitado. 
                Solo queda el fondo negro con los rayos. */}
          </motion.div>
        </div>
      </section>

      {/* Metrics Section */}
      <section id="beneficios" className="bg-brand-blue py-20 relative overflow-hidden">
        <div className="w-full px-4 md:px-8 lg:px-12 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-0 text-center group items-center">
            {/* Métrica 1 */}
            <div className="w-full md:px-6 lg:px-8">
              <div className="flex flex-col items-center justify-center cursor-default transition-all duration-500 group-hover:blur-[2px] group-hover:opacity-60 hover:!blur-none hover:!opacity-100 hover:scale-110">
                <div className="flex items-baseline mb-4">
                  <Counter value={100} />
                  <span className="text-7xl md:text-[7rem] font-display text-brand-yellow tracking-tight leading-none">
                    %
                  </span>
                </div>
                <div className="text-3xl md:text-4xl text-white/90 font-display uppercase tracking-wide text-center">ENERGÍA</div>
              </div>
            </div>

            {/* Métrica 2 */}
            <div className="w-full md:px-6 lg:px-8 md:border-x border-white/20">
              <div className="flex flex-col items-center justify-center cursor-default transition-all duration-500 group-hover:blur-[2px] group-hover:opacity-60 hover:!blur-none hover:!opacity-100 hover:scale-110">
                <div className="flex items-baseline mb-4">
                  <span className="text-7xl md:text-[7rem] font-display text-brand-yellow tracking-tight leading-none">
                    +
                  </span>
                  <Counter value={19} />
                </div>
                <div className="text-3xl md:text-4xl text-white/90 font-display uppercase tracking-wide text-center">MODELOS DISPONIBLES</div>
              </div>
            </div>

            {/* Métrica 3 */}
            <div className="w-full md:px-6 lg:px-8">
              <div className="flex flex-row items-center justify-center gap-4 md:gap-6 cursor-default transition-all duration-500 group-hover:blur-[2px] group-hover:opacity-60 hover:!blur-none hover:!opacity-100 hover:scale-110">
                <div className="w-24 md:w-32 shrink-0 rounded-md overflow-hidden shadow-[0_4px_12px_rgba(0,0,0,0.4)] border border-black/20">
                  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 720 504" className="w-full h-auto block">
                    <rect width="720" height="504" fill="#009c3b"/>
                    <polygon points="360,86 634,252 360,418 86,252" fill="#ffdf00"/>
                    <circle cx="360" cy="252" r="117" fill="#002776"/>
                    <path d="M250,290 Q360,200 470,290" stroke="#fff" strokeWidth="20" fill="none"/>
                  </svg>
                </div>
                <div className="flex flex-col text-left">
                  <span className="text-3xl md:text-4xl text-white/90 font-display uppercase tracking-wide leading-tight">
                    INDUSTRIA<br/>BRASILEÑA
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-8 bg-gray-50 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <h2 className="text-5xl md:text-6xl font-display">¿Por qué elegir <span className="text-brand-blue">THUNDER</span>?</h2>
          </div>

          <div className="flex flex-col lg:flex-row items-center justify-between max-w-7xl mx-auto gap-8 lg:gap-16 relative">
            
            {/* Left Column */}
            <div className="flex flex-col gap-12 w-full lg:w-1/3 z-10">
              {/* Card 1 */}
              <div className={`bg-white p-6 rounded-none shadow-xl border border-gray-100 transition-all duration-500 lg:-translate-x-16 ${isCenterHovered ? '-translate-y-4 shadow-2xl scale-105 border-brand-yellow/50' : 'hover:-translate-y-6 hover:shadow-2xl'}`}>
                <h3 className="text-3xl font-display text-brand-blue mb-3 flex items-center gap-3">
                  <Zap className="w-6 h-6 text-brand-yellow shrink-0" fill="currentColor" /> Arranque Seguro
                </h3>
                <p className="text-black text-lg font-display tracking-wide leading-tight">
                  Alta corriente de arranque (CCA) garantizada para encender tu vehículo sin fallas, exigencias ni excusas, en cualquier clima.
                </p>
              </div>

              {/* Card 2 */}
              <div className={`bg-white p-6 rounded-none shadow-xl border border-gray-100 transition-all duration-500 lg:-translate-x-8 ${isCenterHovered ? '-translate-y-4 shadow-2xl scale-105 border-brand-yellow/50' : 'hover:-translate-y-6 hover:shadow-2xl'}`}>
                <h3 className="text-3xl font-display text-brand-blue mb-3 flex items-center gap-3">
                  <Settings className="w-6 h-6 text-brand-yellow shrink-0" /> Validación Técnica
                </h3>
                <p className="text-black text-lg font-display tracking-wide leading-tight">
                  No vendemos promesas, vendemos evidencia. Somos la única marca que muestra su construcción interna para que compruebes la calidad real del producto.
                </p>
              </div>
            </div>

            {/* Center Image */}
            <div className="w-full lg:w-1/3 flex flex-col items-center justify-center gap-12 relative z-0 py-8 lg:py-0">
              <div 
                ref={containerRef}
                className="relative w-80 h-80 md:w-[28rem] md:h-[28rem] flex items-center justify-center mx-auto cursor-pointer group/center"
                onMouseEnter={() => setIsCenterHovered(true)}
                onMouseLeave={() => setIsCenterHovered(false)}
                onMouseMove={handleMouseMove}
              >
                {/* BASE LAYER (YELLOW) */}
                <div className="absolute inset-0 flex items-center justify-center z-0">
                  {/* Outer glowing ring */}
                  <div className={`absolute inset-0 bg-brand-yellow rounded-full blur-[80px] transition-opacity duration-500 ${isCenterHovered ? 'opacity-60' : 'opacity-30'} animate-pulse`}></div>
                  
                  {/* Realistic Yellow Battery */}
                  <div className={`relative z-10 transition-transform duration-500 ${isCenterHovered ? 'scale-110' : ''}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" className="w-80 h-auto md:w-96 drop-shadow-[0_0_35px_rgba(14,56,157,0.7)]" overflow="visible">
                      {/* Base shadow */}
                      <ellipse cx="200" cy="280" rx="160" ry="20" fill="rgba(0,0,0,0.3)" filter="blur(10px)" />
                      
                      {/* Battery Body (Yellow) */}
                      <rect x="40" y="80" width="320" height="180" rx="15" fill="#F6EB14" stroke="#d4c900" strokeWidth="2" />
                      
                      {/* Top Cover */}
                      <rect x="35" y="70" width="330" height="30" rx="8" fill="#e6db00" stroke="#d4c900" strokeWidth="2" />
                      <rect x="45" y="60" width="310" height="15" rx="5" fill="#d4c900" />

                      {/* Terminals */}
                      {/* Negative (Left) */}
                      <path d="M70 60 L80 30 L110 30 L120 60 Z" fill="#b0b0b0" />
                      <rect x="85" y="20" width="20" height="10" rx="2" fill="#909090" />
                      <circle cx="95" cy="25" r="8" fill="#e0e0e0" />
                      <text x="95" y="50" fontSize="24" fontWeight="bold" fill="#333" textAnchor="middle">-</text>

                      {/* Positive (Right) */}
                      <path d="M280 60 L290 30 L320 30 L330 60 Z" fill="#b0b0b0" />
                      <rect x="295" y="20" width="20" height="10" rx="2" fill="#909090" />
                      <circle cx="305" cy="25" r="8" fill="#e0e0e0" />
                      <text x="305" y="52" fontSize="24" fontWeight="bold" fill="#d00" textAnchor="middle">+</text>

                      {/* Battery Label/Sticker */}
                      <rect x="80" y="110" width="240" height="120" rx="5" fill="#111" />
                      <rect x="85" y="115" width="230" height="110" rx="3" fill="#0E389D" />
                      
                      {/* Lightning Bolt on Sticker */}
                      <path d="M180 130 L150 180 L190 180 L170 210 L220 160 L180 160 Z" fill="#F6EB14" />
                      <text x="230" y="180" fontSize="40" fontWeight="900" fontFamily="Impact, sans-serif" fill="#fff" fontStyle="italic">THUNDER</text>
                      <text x="230" y="200" fontSize="16" fontWeight="bold" fontFamily="sans-serif" fill="#F6EB14">12V 75Ah 650CCA</text>
                      
                      {/* Ribs/Details on side */}
                      <line x1="50" y1="100" x2="50" y2="250" stroke="#d4c900" strokeWidth="4" strokeLinecap="round" />
                      <line x1="60" y1="100" x2="60" y2="250" stroke="#d4c900" strokeWidth="4" strokeLinecap="round" />
                      <line x1="340" y1="100" x2="340" y2="250" stroke="#d4c900" strokeWidth="4" strokeLinecap="round" />
                      <line x1="350" y1="100" x2="350" y2="250" stroke="#d4c900" strokeWidth="4" strokeLinecap="round" />
                    </svg>
                  </div>
                </div>

                {/* OVERLAY LAYER (BLACK SPOTLIGHT) */}
                <div 
                  className="absolute inset-0 flex items-center justify-center pointer-events-none transition-opacity duration-300 z-20"
                  style={{
                    opacity: isCenterHovered ? 1 : 0,
                    WebkitMaskImage: `radial-gradient(circle 180px at ${mousePos.x}px ${mousePos.y}px, black 20%, transparent 100%)`,
                    maskImage: `radial-gradient(circle 180px at ${mousePos.x}px ${mousePos.y}px, black 20%, transparent 100%)`,
                  }}
                >
                  {/* Realistic Black Battery */}
                  <div className={`relative z-10 transition-transform duration-500 ${isCenterHovered ? 'scale-110' : ''}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 300" className="w-80 h-auto md:w-96 drop-shadow-2xl" overflow="visible">
                      {/* Base shadow */}
                      <ellipse cx="200" cy="280" rx="160" ry="20" fill="rgba(0,0,0,0.8)" filter="blur(10px)" />
                      
                      {/* Battery Body (Black) */}
                      <rect x="40" y="80" width="320" height="180" rx="15" fill="#000000" stroke="#222" strokeWidth="2" />
                      
                      {/* Top Cover */}
                      <rect x="35" y="70" width="330" height="30" rx="8" fill="#111" stroke="#222" strokeWidth="2" />
                      <rect x="45" y="60" width="310" height="15" rx="5" fill="#0a0a0a" />

                      {/* Terminals */}
                      {/* Negative (Left) */}
                      <path d="M70 60 L80 30 L110 30 L120 60 Z" fill="#444" />
                      <rect x="85" y="20" width="20" height="10" rx="2" fill="#333" />
                      <circle cx="95" cy="25" r="8" fill="#555" />
                      <text x="95" y="50" fontSize="24" fontWeight="bold" fill="#000" textAnchor="middle">-</text>

                      {/* Positive (Right) */}
                      <path d="M280 60 L290 30 L320 30 L330 60 Z" fill="#444" />
                      <rect x="295" y="20" width="20" height="10" rx="2" fill="#333" />
                      <circle cx="305" cy="25" r="8" fill="#555" />
                      <text x="305" y="52" fontSize="24" fontWeight="bold" fill="#600" textAnchor="middle">+</text>

                      {/* Battery Label/Sticker - KEEP BRIGHT SO SPOTLIGHT DOESN'T AFFECT IT */}
                      <rect x="80" y="110" width="240" height="120" rx="5" fill="#111" />
                      <rect x="85" y="115" width="230" height="110" rx="3" fill="#0E389D" />
                      
                      {/* Lightning Bolt on Sticker */}
                      <path d="M180 130 L150 180 L190 180 L170 210 L220 160 L180 160 Z" fill="#F6EB14" />
                      <text x="230" y="180" fontSize="40" fontWeight="900" fontFamily="Impact, sans-serif" fill="#fff" fontStyle="italic">THUNDER</text>
                      <text x="230" y="200" fontSize="16" fontWeight="bold" fontFamily="sans-serif" fill="#F6EB14">12V 75Ah 650CCA</text>
                      
                      {/* Ribs/Details on side */}
                      <line x1="50" y1="100" x2="50" y2="250" stroke="#222" strokeWidth="4" strokeLinecap="round" />
                      <line x1="60" y1="100" x2="60" y2="250" stroke="#222" strokeWidth="4" strokeLinecap="round" />
                      <line x1="340" y1="100" x2="340" y2="250" stroke="#222" strokeWidth="4" strokeLinecap="round" />
                      <line x1="350" y1="100" x2="350" y2="250" stroke="#222" strokeWidth="4" strokeLinecap="round" />
                    </svg>
                  </div>
                </div>
              </div>

              {/* Card 5 */}
              <div className={`bg-white p-6 rounded-none shadow-xl border border-gray-100 transition-all duration-500 w-full max-w-md ${isCenterHovered ? '-translate-y-4 shadow-2xl scale-105 border-brand-yellow/50' : 'hover:-translate-y-6 hover:shadow-2xl'}`}>
                <h3 className="text-3xl font-display text-brand-blue mb-3 flex items-center gap-3 justify-center">
                  <Globe className="w-6 h-6 text-brand-yellow shrink-0" /> Tecnología e Industria Brasileña
                </h3>
                <p className="text-black text-lg font-display tracking-wide leading-tight text-center">
                  Baterías libres de mantenimiento fabricadas bajo los más altos estándares internacionales, asegurando máxima durabilidad y rendimiento superior.
                </p>
              </div>
            </div>

            {/* Right Column */}
            <div className="flex flex-col gap-12 w-full lg:w-1/3 z-10">
              {/* Card 3 */}
              <div className={`bg-white p-6 rounded-none shadow-xl border border-gray-100 transition-all duration-500 lg:translate-x-16 ${isCenterHovered ? '-translate-y-4 shadow-2xl scale-105 border-brand-yellow/50' : 'hover:-translate-y-6 hover:shadow-2xl'}`}>
                <h3 className="text-3xl font-display text-brand-blue mb-3 flex items-center gap-3">
                  <Truck className="w-6 h-6 text-brand-yellow shrink-0" /> Red de Distribución Estratégica
                </h3>
                <p className="text-black text-lg font-display tracking-wide leading-tight">
                  Cobertura sólida con puntos clave a nivel nacional. Aseguramos disponibilidad constante de stock y respaldo comercial directo para hacer crecer tu negocio.
                </p>
              </div>

              {/* Card 4 */}
              <div className={`bg-white p-6 rounded-none shadow-xl border border-gray-100 transition-all duration-500 lg:translate-x-8 ${isCenterHovered ? '-translate-y-4 shadow-2xl scale-105 border-brand-yellow/50' : 'hover:-translate-y-6 hover:shadow-2xl'}`}>
                <h3 className="text-3xl font-display text-brand-blue mb-3 flex items-center gap-3">
                  <Shield className="w-6 h-6 text-brand-yellow shrink-0" /> Instalación y Prueba Rápida
                </h3>
                <p className="text-black text-lg font-display tracking-wide leading-tight">
                  Servicio ágil y sin complicaciones. Optimizamos el tiempo en el punto de venta para brindar confianza inmediata tanto al distribuidor como al cliente final.
                </p>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* Products Preview */}
      <section className="py-24 bg-brand-gray/30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-end mb-12 gap-6">
            <div>
              <h2 className="text-5xl md:text-6xl mb-4">Productos Destacados</h2>
              <p className="text-brand-gray/60">Nuestros modelos más solicitados por distribuidores.</p>
            </div>
            <Link to="/productos" className="flex items-center text-brand-blue font-bold uppercase tracking-widest hover:translate-x-2 transition-transform">
              Ver Catálogo Completo <ChevronRight className="ml-2 w-5 h-5" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {PRODUCTS.filter(p => ['WFEX65D', 'WFEX80D', 'WFEX110E', 'WFEX150MD'].includes(p.id)).map((product) => (
              <div key={product.id} className="bg-white p-6 shadow-sm hover:shadow-xl transition-shadow border border-brand-gray">
                <div className="aspect-square bg-brand-gray/20 mb-6 flex items-center justify-center p-4">
                  <img src={`https://picsum.photos/seed/${product.id}/400/400`} alt={product.id} className="max-w-full h-auto" referrerPolicy="no-referrer" />
                </div>
                <div className="text-xs font-bold text-brand-blue mb-2">{product.brand} — {product.category}</div>
                <h3 className="text-2xl mb-4">{product.id}</h3>
                <div className="grid grid-cols-2 gap-4 mb-6 text-xs border-y border-brand-gray py-4">
                  <div>
                    <span className="block text-brand-gray/50 uppercase mb-1">Amperaje</span>
                    <span className="font-bold">{product.amp} Ah</span>
                  </div>
                  <div>
                    <span className="block text-brand-gray/50 uppercase mb-1">CCA</span>
                    <span className="font-bold">{product.cca}</span>
                  </div>
                </div>
                <Link to="/productos" className="block w-full text-center py-3 bg-brand-black text-white font-display text-lg hover:bg-brand-blue transition-colors">
                  VER DETALLES
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Preview */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-5xl md:text-6xl mb-6">Respaldo y <span className="text-brand-blue">Confianza</span></h2>
              <p className="text-lg text-brand-gray/70 mb-8 leading-relaxed">
                THUNDER Bolivia es una marca especializada en la comercialización de baterías de alto rendimiento. 
                Contamos con un equipo de liderazgo experimentado que garantiza el crecimiento del sector automotriz.
              </p>
              <Link to="/acerca-de" className="bg-brand-blue text-white px-8 py-4 font-display text-2xl hover:bg-brand-black transition-colors inline-block">
                CONOCE MÁS SOBRE NOSOTROS
              </Link>
            </div>
            
            <div className="grid grid-cols-1 gap-8">
              {TEAM.map((member, i) => (
                <div key={i} className="flex flex-col sm:flex-row items-center gap-8 p-8 bg-brand-gray/20 border-l-4 border-brand-blue">
                  <img src={member.image} alt={member.name} className="w-32 h-32 rounded-full object-cover grayscale hover:grayscale-0 transition-all" />
                  <div>
                    <h3 className="text-3xl mb-1">{member.name}</h3>
                    <div className="text-brand-blue font-bold text-sm uppercase tracking-widest mb-4">{member.role}</div>
                    <p className="text-brand-gray/70 text-sm mb-4">{member.description}</p>
                    <a href={member.linkedin} target="_blank" rel="noopener noreferrer" className="text-brand-blue hover:underline text-xs font-bold uppercase">LinkedIn Profile</a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-brand-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl md:text-6xl mb-4">Lo que dicen nuestros <span className="text-brand-yellow">aliados</span></h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {TESTIMONIALS.map((t, i) => (
              <div key={i} className="p-8 bg-white/5 border border-white/10 relative">
                <Star className="w-8 h-8 text-brand-yellow mb-6 fill-brand-yellow" />
                <p className="text-lg italic mb-8 text-brand-gray/80">"{t.text}"</p>
                <div>
                  <div className="font-bold text-xl">{t.name}</div>
                  <div className="text-brand-yellow text-xs uppercase tracking-widest">{t.role} — {t.location}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Banner */}
      <section className="relative py-24 bg-brand-blue overflow-hidden">
        <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/battery-bg/1920/1080')] bg-cover bg-center opacity-20 mix-blend-overlay" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
          <h2 className="text-5xl md:text-7xl text-white mb-8">¿QUERÉS VENDER <span className="text-brand-yellow">THUNDER</span> EN TU ZONA?</h2>
          <p className="text-xl text-white/80 mb-12 max-w-2xl mx-auto">
            Únete a nuestra red de distribuidores autorizados y haz crecer tu negocio con productos de alta rotación.
          </p>
          <a
            href="https://wa.me/59176238388?text=Hola,%20quiero%20informaci%C3%B3n%20para%20convertirme%20en%20distribuidor%20autorizado%20de%20bater%C3%ADas%20THUNDER%20en%20mi%20zona."
            className="bg-brand-yellow text-brand-black px-12 py-5 font-display text-3xl hover:bg-white transition-colors inline-flex items-center"
          >
            CONTACTAR POR WHATSAPP
          </a>
        </div>
      </section>
    </div>
  );
}
