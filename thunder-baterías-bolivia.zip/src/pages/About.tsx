import React from 'react';
import { motion } from 'motion/react';
import { TEAM } from '@/src/constants';

export default function About() {
  return (
    <div className="pt-20">
      {/* Hero */}
      <section className="relative py-32 bg-brand-black text-white overflow-hidden">
        <div className="absolute inset-0 opacity-30">
          <img src="https://picsum.photos/seed/automotive-workshop/1920/1080" alt="Background" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          <div className="absolute inset-0 bg-gradient-to-r from-brand-black via-brand-black/80 to-transparent" />
        </div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
          >
            <h1 className="text-6xl md:text-8xl mb-4">LA MARCA QUE <span className="text-brand-yellow">BOLIVIA</span> NECESITABA</h1>
            <p className="text-2xl text-brand-gray/80 max-w-2xl font-light">
              Más que una batería — un compromiso con el arranque seguro y la durabilidad extrema.
            </p>
          </motion.div>
        </div>
      </section>

      {/* History */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-5xl mb-8">Nuestra <span className="text-brand-blue">Historia</span></h2>
              <div className="space-y-6 text-brand-gray/70 text-lg leading-relaxed">
                <p>
                  THUNDER Bolivia nace de la necesidad de ofrecer al mercado nacional una alternativa de energía automotriz que realmente cumpla con lo que promete. En un entorno donde las condiciones geográficas y climáticas exigen el máximo de cada componente, THUNDER se posiciona como el aliado estratégico de conductores y empresas.
                </p>
                <p>
                  Importadas directamente desde Brasil, nuestras baterías cuentan con tecnología de punta y procesos de fabricación certificados internacionalmente. No solo vendemos un producto; ofrecemos la tranquilidad de saber que tu vehículo arrancará siempre, sin importar las condiciones.
                </p>
                <p>
                  Hoy, bajo la gestión de Distribución Rooney, estamos expandiendo nuestra red para llegar a cada rincón de Bolivia, consolidándonos como referentes de calidad y respaldo técnico.
                </p>
              </div>
            </div>
            <div className="relative">
              <img src="https://picsum.photos/seed/thunder-history/800/1000" alt="History" className="w-full h-auto shadow-2xl" referrerPolicy="no-referrer" />
              <div className="absolute -bottom-8 -left-8 bg-brand-blue p-8 text-white hidden md:block">
                <div className="text-5xl font-display mb-1">100%</div>
                <div className="text-xs uppercase tracking-widest font-bold">Energía Real</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24 bg-brand-gray/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="bg-white p-12 border-t-8 border-brand-blue shadow-lg">
              <h3 className="text-4xl mb-6 text-brand-blue">MISIÓN</h3>
              <p className="text-lg text-brand-gray/70 leading-relaxed">
                Comercializar baterías automotrices de alto rendimiento, construyendo una red sólida de distribuidores autorizados con respaldo técnico, instalación rápida y cobertura estratégica en Bolivia.
              </p>
            </div>
            <div className="bg-white p-12 border-t-8 border-brand-yellow shadow-lg">
              <h3 className="text-4xl mb-6 text-brand-black">VISIÓN</h3>
              <p className="text-lg text-brand-gray/70 leading-relaxed">
                Convertir a THUNDER en la marca referente de baterías automotrices en Bolivia, liderando el mercado con una propuesta basada en calidad, respaldo técnico y dominio estratégico del canal de distribución.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team Full */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl md:text-6xl mb-4">Nuestro <span className="text-brand-blue">Equipo</span></h2>
            <p className="text-brand-gray/60 max-w-2xl mx-auto">
              El liderazgo y la experiencia que respaldan la marca THUNDER en todo el país.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 justify-center">
            {TEAM.map((member, i) => (
              <div key={i} className="text-center group">
                <div className="relative mb-6 inline-block">
                  <div className="absolute inset-0 bg-brand-blue rounded-full scale-105 opacity-0 group-hover:opacity-100 transition-opacity" />
                  <img src={member.image} alt={member.name} className="w-48 h-48 rounded-full object-cover relative z-10 grayscale group-hover:grayscale-0 transition-all border-4 border-white" />
                </div>
                <h3 className="text-3xl mb-1">{member.name}</h3>
                <div className="text-brand-blue font-bold text-sm uppercase tracking-widest mb-4">{member.role}</div>
                <p className="text-brand-gray/70 text-sm max-w-xs mx-auto mb-6">{member.description}</p>
                <a href={member.linkedin} target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-brand-blue font-bold hover:underline">
                  Ver Perfil de LinkedIn
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
